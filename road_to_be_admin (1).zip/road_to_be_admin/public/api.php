<?php
require dirname(__FILE__).DIRECTORY_SEPARATOR."lib/config.php";
require dirname(__FILE__).DIRECTORY_SEPARATOR."lib/User.class.php";
require dirname(__FILE__).DIRECTORY_SEPARATOR."lib/Admin.class.php";
require dirname(__FILE__).DIRECTORY_SEPARATOR."lib/functions.php";

$username = $_REQUEST['username'];
$password = $_REQUEST['password'];
$acc = [$username, $password];
main($acc);
