<?php
function gen_user_db($acc){
	$path = dirname(__FILE__).DIRECTORY_SEPARATOR;
	$path .= "db".DIRECTORY_SEPARATOR;
	$path .= "account.db";
	if (file_exists($path)) return false;
	else {
		global $admin;
		$u = new User($acc);
		$fmt = sprintf("%s|%s|%d,", $admin['username'], $u->gen_hash($admin['password']), $admin['level']);
		file_put_contents($path, $fmt);
	}
}
function gen_pass_db($len=5){
	$path = dirname(__FILE__).DIRECTORY_SEPARATOR;
	$path .= "db".DIRECTORY_SEPARATOR;
	$path .= "secretcode.db";
	if (file_exists($path)) return false;
	else {
		$rand_str = "`~1234567890-=!@#$%^&*()_+qwertyuiopT[]\\";
		$rand_str .= "asdfghjkl;':\"zxcvbnm./<>?QWERASDFZCVBNM";
		$res = '';
		for($i = 0; $i < $len; $i++){
			$res .= $rand_str[rand(0, strlen($rand_str)) - 1];
		}
		file_put_contents($path, $res);
	}
}
function challenge($obj){
	if ($obj->is_login()) {
		$admin = new Admin();
		if (!$admin->is_admin()) $admin->redirect('/api.php?#access denied');
		$cmd = $_REQUEST['cmd2'];
		if ($cmd) {
			switch($cmd){
				case "eu":
					echo json_encode($admin->export_users());
					break;
				case "ed":
					echo json_encode($admin->export_db($_REQUEST['db_file']));
					break;
				case "gp":
					echo json_encode($admin->receive_pass());
					break;
				case "cf":
					echo json_encode($admin->compare_flag($_REQUEST['flag']));
					break;
			}
		}
	}
}
function main($acc){
	gen_user_db($acc);
	gen_pass_db();
	header("Content-Type: application/json");
	$user = new User($acc);
	$cmd = $_REQUEST['cmd'];
	usleep(500000);
	switch($cmd){
		case 'i':
			if (!$user->signin())
				echo "Sai ten va mat khau.\n\n";
			break;
		case 'u':
			if ($user->signup())
				echo "Dang ky thanh cong!\n\n";
			else
				echo "Dang ky that bai\n\n";
			break;
		case 'o':
			if ($user->signout())
				echo "Dang xuat khoi trai dat thanh cong!\n\n";
			else
				echo "Hay o lai di, dung dang xuat..\n\n";
			break;
	}
	challenge($user);
}
