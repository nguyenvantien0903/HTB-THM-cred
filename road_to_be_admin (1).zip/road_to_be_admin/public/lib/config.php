<?php
$admin = ['username' => "*secret*", 'password' => "*secret*", 'level' => 1]; 
