<?php
class Admin extends User {
	private $sess;
	private $db;
	public function __construct(){
		$this->sess = $_SESSION;
		$this->db['path'] = dirname(__FILE__).DIRECTORY_SEPARATOR;
		$this->db['path'] .= "db".DIRECTORY_SEPARATOR;
		$this->db['path'] .= "secretcode.db";
	}
	public function is_admin(){
		if ($this->sess[2]) return true;
	}
	public function export_users(){
		if ($this->is_pass_correct()) {
			$path = dirname(__FILE__).DIRECTORY_SEPARATOR;
			$path .= "db".DIRECTORY_SEPARATOR;
			$path .= "account.db";
			$data = file_get_contents($path);
			$data = explode(',', $data, -1);
			$arr = [];
			for($i = 0; $i < count($data); $i++){
				$tmp = explode('|', $data[$i]);
				$arr[] = $tmp[0];
			}
			return $arr;
		}else 
			return "secretcode khong giong du lieu dau vao";
	}
	public function export_db($file){
		if ($this->is_pass_correct()) {
			$path = dirname(__FILE__).DIRECTORY_SEPARATOR;
			$path .= "db".DIRECTORY_SEPARATOR;
			$path .= $file;
			$data = file_get_contents($path);
			$data = explode(',', $data);
			$arr = [];
			for($i = 0; $i < count($data); $i++){
				$arr[] = explode('|', $data[$i]);
			}
			return $arr;
		}else 
			return "secretcode khong giong du lieu dau vao";
	}
	public function is_pass_correct(){
		$secretcode = $this->receive_pass();
		$input = $_REQUEST['secret'];
		if ($input == $secretcode) return true;
	}
	public function receive_pass(){
		return file_get_contents($this->db['path']);
	}
	public function compare_flag($flag){
		$this->flag = trim(file_get_contents("/flag"));
		if ($this->flag == $flag) return "Dung roi chinh la no! Flag!!!!!";
		else return "Day deo phai flag";
	}
	public function __destruct(){
		$this->signout();
	}
}
